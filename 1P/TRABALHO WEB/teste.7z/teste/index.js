console.log("Script inicializado");

const inputNome = document.getElementsById("inputNome");
const inputIdade = document.getElementsById("inputIdade");
const inputCPF = document.getElementsById("inputCPF");
const botaoSalvar = document.getElementsById("botaoSalvar");
const divResponse = document.getElementsById("responseContainer");

botaoSalvar.addEventListener("click", botaoAction);

function botaoAction(){
    alert("heitorbobão");
    console.log("text");

    let nome = inputNome.value;
    let idade = inputIdade.value;

    console.log(nome);
    console.log(idade);
}